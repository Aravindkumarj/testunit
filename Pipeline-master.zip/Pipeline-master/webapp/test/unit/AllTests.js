sap.ui.define([
	"sapui5demoapp-01/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
